package com.example.demo_EMS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoEmsApplication {
	public static void main(String[] args) {
		SpringApplication.run(DemoEmsApplication.class, args);
	}
}